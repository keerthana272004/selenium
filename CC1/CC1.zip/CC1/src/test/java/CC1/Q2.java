package CC1;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class Q2 {
		public static void main(String[] args) throws InterruptedException {
			// TODO Auto-generated method stub
			WebDriverManager.chromedriver().setup();
			ChromeOptions co = new ChromeOptions();
			co.addArguments("--remote-allow-origins=*");
			WebDriver driver = new ChromeDriver(co);
			driver.get("https://www.saucedemo.com/");
			Actions a=new Actions (driver);
			driver.get("https://www.saucedemo.com/");
			WebElement user=driver.findElement(By.id("user-name"));
			WebElement pass=driver.findElement(By.id("password"));
			WebElement button=driver.findElement(By.id("login-button"));
			user.sendKeys("standard_user");
			pass.sendKeys("secret_sauce");
			button.click();
			Thread.sleep(3000);
			WebElement azElement=driver.findElement(By.xpath("//*[@id=\"item_4_title_link\"]/div"));
			String az = azElement.getText();
			System.out.println("ProductName A-Z: "+az);
			WebElement dropdown=driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/div/span/select"));
			Select select = new Select(dropdown);
			select.selectByValue("za");
			WebElement zaElement=driver.findElement(By.xpath("//*[@id=\"item_3_title_link\"]/div"));
			String za = zaElement.getText();
			System.out.println("ProductName Z-A: "+za);
			WebElement dropdown1=driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/div/span/select"));
			Select select1 = new Select(dropdown1);
			select1.selectByValue("lohi");
			WebElement lohiElement=driver.findElement(By.xpath("//*[@id=\"item_2_title_link\"]/div"));
			String lohi = lohiElement.getText();
			System.out.println("ProductName LowToHigh: "+lohi);
			WebElement dropdown2=driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/div/span/select"));
			Select select2 = new Select(dropdown2);
			select2.selectByValue("hilo");
			WebElement hiloElement=driver.findElement(By.xpath("//*[@id=\"item_5_title_link\"]/div"));
			String hilo = hiloElement.getText();
			System.out.println("ProductName HighToLow: "+hilo);
			
			

		}



}
