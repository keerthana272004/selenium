package CA1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class q1 {
	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		WebDriver driver;
		ChromeOptions co=new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		driver=new ChromeDriver(co);
		driver.navigate().to("https://www.amazon.in/Hygear-Xpress-White-Slipper_7-HGGE1004/dp/B0BRKCXLY8/ref=sxin_25_trfobq2av2_0_B0BRKCXLY8?content-id=amzn1.sym.c1eb4b2a-b703-404b-a097-61cb8a5ee3cb%3Aamzn1.sym.c1eb4b2a-b703-404b-a097-61cb8a5ee3cb&crid=296NC2SDHKVBH&cv_ct_cx=slipper&keywords=slipper&pd_rd_i=B0BRKCXLY8&pd_rd_r=37ea5620-21e7-4e22-8abf-3e94eb54b3dc&pd_rd_w=52vRq&pd_rd_wg=VN8zI&pf_rd_p=c1eb4b2a-b703-404b-a097-61cb8a5ee3cb&pf_rd_r=N3VC7W9BNCR41QGVX81K&qid=1683194647&sbo=RZvfv%2F%2FHxDF%2BO5021pAnSA%3D%3D&sprefix=slip%2Caps%2C1264&sr=1-1-973fd8bd-28ce-479e-8be4-fbaf1193947a&th=1&psc=1");
		driver.manage().window().maximize();
		WebElement addtocart=driver.findElement(By.id("add-to-cart-button"));
		addtocart.click();
		WebElement proceedtobuy=driver.findElement(By.name("proceedToRetailCheckout"));
		proceedtobuy.click();
		WebElement cartbutton=driver.findElement(By.xpath("//*[@id=\"attach-sidesheet-view-cart-button\"]/span/input"));
		cartbutton.click();
		
		System.out.print("Sucessfully placed order");
		
		
	     	
	}

}