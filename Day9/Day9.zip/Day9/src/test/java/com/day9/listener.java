package com.day9;

import org.testng.annotations.Test;

public class listener {
  @Test
  public void f() {
  }
}
