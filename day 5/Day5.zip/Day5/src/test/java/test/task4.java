package test;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class task4 {
	public static void main(String[] args) throws InterruptedException 
	{
		WebDriverManager.chromedriver().setup();
        ChromeOptions co=new ChromeOptions();
        co.addArguments("--remote-allow-origins=*");
        WebDriver driver=new ChromeDriver(co);
        driver.get("https://www.abhibus.com/bus-ticket-booking");
        WebElement leaving_from = driver.findElement(By.id("source"));
        WebElement going_to = driver.findElement(By.id("destination"));  
        WebElement date = driver.findElement(By.xpath("//*[@id=\"datepicker1\"]"));
        leaving_from.sendKeys("Chennai");
        Thread.sleep(3000);
        leaving_from.sendKeys(Keys.ENTER);
        going_to.sendKeys("Erode");
        Thread.sleep(3000);
        date.click();
        JavascriptExecutor js=(JavascriptExecutor)driver;
        js.executeScript("arguments[0].setAttribute('value','03-05-2023')",date);
        WebElement search=driver.findElement(By.xpath("//*[@id=\"ui-datepicker-div\"]/div[2]/table/tbody/tr[1]/td[3]/a"));
        search.click();
           
	}
}